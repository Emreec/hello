var http = require('http');
var fs = require('fs');

var index=fs.readFileSync('index.html');






const { SerialPort } = require('serialport')
const { ReadlineParser } = require('@serialport/parser-readline')
const port = new SerialPort({ path: 'COM3', baudRate: 19200 ,dataBits: 8,
    parity: 'none',
    stopBits: 1,
    flowControl: false  })

const parser = port.pipe(new ReadlineParser({ delimiter: '\r\n' }))



var app = http.createServer(function(req, res) {
    res.writeHead(700, {'Content-Type': 'text/html'});
    res.end(index);
});

var io = require('socket.io')(app);

io.on('connection', socket => {
    
    console.log('Node is listening to port');
    
});

parser.on('data' , function(data) {
    var arr=[]
    data=data.split(",")
    arr.push(data)
    console.log('Received angle data: ' , data[0] ); 
    console.log('Received force data: ' , data[1] );
    console.log('Received angle radian data: ' , data[2] );
    console.log('Received torque data: ' , data[3] );
    console.log('Received gauge angle data: ' , data[4] );
    console.log('Received gauge angle radian data: ' , data[5] );
    console.log('Received polar moment data: ' , data[6] );
    console.log('Received surfca shear stress data: ' , data[7] );
    console.log('Received surfca shear strain data: ' , data[8] );
    console.log('Received force peak data: ' , data[9] );
    io.emit('data', data[0] );
    io.emit('data1',data[1]);
    io.emit('data2',data[2]);
    io.emit('data3',data[3]);
    io.emit('data4',data[4]);
    io.emit('data5',data[5]);
    io.emit('data6',data[6]);
    io.emit('data7',data[7]);
    io.emit('data8',data[8]);
    io.emit('data9',data[9]);
    

});

app.listen(3000);