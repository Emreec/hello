

# Create your views here.
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
#from home.MKK_Communications import MessageStructureClass
from users.models import DataEbotUser
from .forms import CustomUserCreationForm, EditUserForm 
from django.contrib.auth.forms import UserChangeForm
from django.contrib import messages


from Domain.models import *
from MedicineData.models import *
from EbotShelf.models import *
from MedicineModel.models import *
from UploadMedd.models import *

import logging


import minimalmodbus
import serial


axisX = 0X01
axisY = 0X7F




TIME_OUT_IN_LOOP = 10000; #10sn bekleme
TIME_BTW_MODBUS_CMD = 20; #Modbus Komutları Arasında Bekleme sabiti - 50ms - 25ms sorunsuz idi
TIME_TO_DROP_MEDICINE = 1500; # Kapak açıkken bekleme sabiti
TIME_BTW_TRY = 250; #İlaç alma sırasında alamaz ise bekleme sabiti
TIME_TO_WAIT = 20; #Genel bekleme sabiti
BAUDRATE = 115200; #RS485 BAUD RATE

class PreDefinedShelf():
    WAIT = 0
    DROP_LOC_1 = -1    
    DROP_LOC_2 = -2
    DROP_LOC_3 = -4
    DROP_LOC_4 = -5 
    DROP_LOC_5 = -6
    DROP_LOC_6 = -7
    DROP_LOC_7 = -8
    DROP_LOC_8 = -9
    DROP_LOC_9 = -10
    DROP_LOC_10 = -11
    HOMING = -3


class ServoDriveParameters():
    P00_01 = 0x0002   #Alarm Status
    P00_09 = 0x0012   #Input pulse command value
    P00_10 = 0x0014   #Servo Status
    P00_11 = 0x0016   #Digital Input Status
    P00_12 = 0x0018   #Digital out status
    P00_13 = 0x001A   #IGBT Temprature

    P02_10 = 0x0214   #DI1 - Servo On
    P02_30 = 0x023C   #AUX Function
    P05_07 = 0x050E   #Comm PR Trigger
    P06_03 = 0x0606   #Path1 Data
    P06_05 = 0x060A   #Path2 Data #shortmovement la beraber Y de kısa hareketi anlatıyor
    P06_07 = 0x060E   #Path3 Data
    P06_09 = 0x0612   #Path4 Data
    P06_11 = 0x0616   #Path5 Data



class ServoDriveData():
    HOME = 0x0000
    SRV_ON = 0x0001
    SRV_OFF = 0x0101
    EEPROM_DSBL = 0x0005
    PR01 = 0x0001 
    PR02 = 0x0002 
    PR03 = 0x0003 
    PR04 = 0x0004 
    PR05 = 0x0005 
    PR62 = 0x003E #EBOTUN haaznenin ilacı alma amacıyla yukarı doğru hareket etmesi
    PR63 = 0x003F #EBOTUN haznenin aşağıya belli bir mesafe gitmesi
    STOP = 0x03E8


def GetX_mmToPulse(): #paramName = database operation , name = 
    name = EbotParameters.objects.get(paramName = 'X_MM_TO_PULSE')
    value = float(name.paramValue)
    return value
    #return -1 yapmadık gerekebilir.
    

def GetY_mmToPulse():
    name = EbotParameters.objects.get(paramName = 'Y_MM_TO_PULSE')
    value = float(name.paramValue)
    return value
    #return -1 yapmadık gerekebilir.


def GetDilX_HomeRef():
    name = EbotParameters.objects.get(paramName = 'DIL_X_HOME_REF')
    value = float(name.paramValue)
    return value #float gerekmeyebilir

def GetDilY_HomeRef():
    name = EbotParameters.objects.get(paramName = 'DIL_Y_HOME_REF')
    value = float(name.paramValue)
    return value


def  GetCoordinateRefPoint(): #A B C D gönderir 
    name = EbotParameters.objects.get(paramName = 'COOR_REF_POINT')
    value = name.paramValue
    return value


def GetShortMovementValue():
    name = EbotParameters.objects.get(paramName = 'SHORT_MOVE')
    value = int(name.paramValue)
    return value




def MoveToMedicine(request , medicineName):
    
    try:
        GetMedInfo = MedicineModel.objects.get(MedName = medicineName)
        #MedNameCheck = MedicineModel.objects.all()
        GetStatus = GetMedInfo.isActive
        if GetStatus == True:
            xPositionAbs = float(GetMedInfo.xPositionAbs)
            yPositionAbs = float(GetMedInfo.yPositionAbs)
            print(GetMedInfo.isActive)
            
            GetMedInfo.quantity = GetMedInfo.quantity - 1
            if GetMedInfo.quantity == 0: 
                GetMedInfo.isActive = False
            
            GetMedInfo.save()
            print(xPositionAbs)
            command = 0
            OpLst = [command , xPositionAbs , yPositionAbs]
            print(OpLst)
            ModbusWriteMultipleProject(OpLst)
        else:
            return 1
    except MedicineModel.DoesNotExist:
        
        return 0


def uMoveToMedicine(uMedPos , registerMedicineName):
    try:
        print(uMedPos)
        print(registerMedicineName)
        uOperationList = []
        command = 1
        uGetMedInfo =  uMedicineModel.objects.get(uPosition = uMedPos)
        uXpos = uGetMedInfo.UxPositionAbs
        uYpos = uGetMedInfo.UyPositionAbs
        QAvailableShelf = MedicineModel.objects.filter(quantity = 1) 
        AvailableShelf = MedicineModel.objects.filter(isActive = False)
        print(type(QAvailableShelf))
        
        a = 0
        
        for j in QAvailableShelf:
            if j.MedName == registerMedicineName:
                K = MedicineModel.objects.get(MedName = registerMedicineName)
                LoadXPosP = j.xPositionAbs
                LoadYPosP = j.yPositionAbs
                K.quantity = K.quantity + 1
                a=1
                K.save()
                uOperationList.append((command , uXpos , uYpos , LoadXPosP , LoadYPosP))
                print("ilk fordayız selamlar")
                print(uOperationList)
                return uModbusWriteMultipleProject(*uOperationList)
        if a==0:
            for i in AvailableShelf:
                Pos = i.Position
                LoadXPos = i.xPositionAbs
                LoadYPos = i.yPositionAbs
                ActivateMed = MedicineModel.objects.get(Position = Pos)
                ActivateMed.isActive = True
                ActivateMed.quantity = ActivateMed.quantity + 1
                
                ActivateMed.MedName = registerMedicineName
                ActivateMed.save()
                uOperationList.append((command , uXpos , uYpos , LoadXPos , LoadYPos))
                print(uOperationList)
                print("burası itemi tutar: ", i)
                return uModbusWriteMultipleProject(*uOperationList)
        if not QAvailableShelf and not AvailableShelf:
            return 0
    except: 
        return 2



def ModbusWriteMultipleProject(operationList):
    instrument = minimalmodbus.Instrument('COM4', 1)
    instrument.serial.port              # this is the serial port name
    instrument.serial.baudrate = 19200        # Baud
    instrument.serial.bytesize = 8
    instrument.serial.parity   = serial.PARITY_NONE
    instrument.serial.stopbits = 2
    instrument.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
    instrument.clear_buffers_before_each_transaction = True
    instrument.serial.timeout  = 0.9
    #try:
    
    instrument.write_register(0 , operationList [0])
    instrument.write_float(1 , operationList [1],2)
    instrument.write_float(2 , operationList [2],2)
    print(operationList[0],operationList[1],operationList[2])
    print(operationList) #buradaki data to write içerisinde bulunduran bir liste olarak tanımlanması gerekebilir
    return True
    #except:
        #print("Modbus Write Multiple sırasında hata oluştu. ")
        #return False

def uModbusWriteMultipleProject(operationList):
    print("Kod buraya geldi")
    instrument = minimalmodbus.Instrument('COM4', 1)
    instrument.serial.port              # this is the serial port name
    instrument.serial.baudrate = 19200        # Baud
    instrument.serial.bytesize = 8
    instrument.serial.parity   = serial.PARITY_NONE
    instrument.serial.stopbits = 2
    instrument.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
    instrument.clear_buffers_before_each_transaction = True
    instrument.serial.timeout  = 0.9
    #try:
    print(operationList[0])
    print(operationList[1])
    
    instrument.write_register(0 , operationList [0])
    instrument.write_float(1 , operationList [1],2)
    instrument.write_float(2 , operationList [2],2)
    instrument.write_float(3 , operationList [3],2)
    instrument.write_float(2 , operationList [4],2)
   
    print(operationList[0],operationList[1],operationList[2])
    print(operationList) #buradaki data to write içerisinde bulunduran bir liste olarak tanımlanması gerekebilir
    return True
    #except:
        #print("Modbus Write Multiple sırasında hata oluştu. ")
        #return False









































































def GetservicePointCoordinates():
    #if(servicePointCoordinatess!=null)
        #if (servicePointCoordinatess.Count == 0)
    
    name = EbotParameters.objects.all()
    j = 0
    finalValues = [0]*len(name)
    for i in name:
        if i.paramName ==  'SERVICE_POINT':
            value = i.paramValue
            if value[0] == '[' and value[-1] == ']':
                #temp = value[1:-1]  #scartando la frase # ociano fatto beyne
                tempArray = value[1:-1].split(":")
                sonuc = [0X0F , 0X0F]
                sonuc[0] = float(tempArray[1])  
                sonuc[1] = float(tempArray[2]) 
                print("sonuc:", sonuc)
                finalValues[j] = sonuc  
                j += 1 
    print("bu bir stringtir" , finalValues) #bu bir stringtir [[50.0, -900.0], [50.0, -500.0], [-2400.0, -890.0], [-2400.0, -490.0], 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    return finalValues
    #    else:
    #        print('Bazı referans bilgileri çözümlenemedi, lütfen veritabanında bulunan bilgileri kontrol ediniz.')

####MODBUS/PreparePrToMove

def ModBusRead(slaveAddr , parameterAddr , numOfRegisterToRead): #BURADAKİ parameterAddryi gönderildiği yerde kullanırken ServoDriveParametersla birlikte kullanılmak zorunda , C# ushort kullanımı gerekebilir
    
    instrument = minimalmodbus.Instrument('COM5', slaveAddr, debug=True)  # port name, slave address (in decimal) # COM5 rastgele yazıldı 
    instrument.serial.port              # this is the serial port name
    instrument.serial.baudrate = BAUDRATE         # Baud
    instrument.serial.bytesize = 8
    instrument.serial.parity   = serial.PARITY_NONE
    instrument.serial.stopbits = 2
    instrument.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
    instrument.clear_buffers_before_each_transaction = True
    #instrument.serial.timeout  = 0.2
    #try: 
    print("283")
    result = instrument.read_registers( parameterAddr, numOfRegisterToRead) #Parametre adresi formatında bir okunamamazlık olabilir
    print(result)
    print("Modbus read çalıştı")
    return result 
    #except:
        #print("Modbus Read sırasında hata oluştu. ")
        #return None


def ModBusWriteSingle(slaveAddr , parameterAddr , dataToWrite):

    instrument = minimalmodbus.Instrument('COM5',slaveAddr)
    instrument.serial.port              # this is the serial port name
    instrument.serial.baudrate = BAUDRATE         # Baud
    instrument.serial.bytesize = 8
    instrument.serial.parity   = serial.PARITY_NONE
    instrument.serial.stopbits = 2
    instrument.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
    #instrument.clear_buffers_before_each_transaction = True
    #instrument.serial.timeout  = 0.2
    #try:
    instrument.write_register(parameterAddr , dataToWrite , 0  ) #buradaki 0 number of decimals , değiştirilmesi gerekebilir
    return True
    #except:
    #    print("Modbus Write Single sırasında hata oluştu. ")
    #    return False


def ModBusWriteMultiple(slaveAddr , parameterAddr , dataToWrite):
    
    instrument = minimalmodbus.Instrument('COM5', slaveAddr)
    instrument.serial.port              # this is the serial port name
    instrument.serial.baudrate = BAUDRATE         # Baud
    instrument.serial.bytesize = 8
    instrument.serial.parity   = serial.PARITY_NONE
    instrument.serial.stopbits = 2
    instrument.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
    #instrument.clear_buffers_before_each_transaction = True
    #instrument.serial.timeout  = 0.2
    #try:
    instrument.write_registers(parameterAddr , dataToWrite) #buradaki data to write içerisinde bulunduran bir liste olarak tanımlanması gerekebilir
    return True
    #except:
        #print("Modbus Write Multiple sırasında hata oluştu. ")
        #return False


def ConvertUshortArrayToInt(_shortForInt): #Buraya liste olarak gelmeli 
    if len(_shortForInt) > 2:
        return -1
    return _shortForInt[0] + (_shortForInt[1]<<16) 


def X_CurrentPosition():
    return ConvertUshortArrayToInt(ModBusRead(axisX , ServoDriveParameters.P00_09 , 2))

def Y_CurrentPosition():
    return ConvertUshortArrayToInt(ModBusRead(axisY , ServoDriveParameters.P00_09 , 2))


def Convert2WriteInt32(_intForShort):
    resultData = [0 , 0]
    resultData[1] = ((_intForShort & 0XFFFF0000) >> 16) #bitwise and &
    resultData[0] = (_intForShort & 0X0000FFFF)
    return resultData





def PreparePrToMove(shelfID):
    #float(xPRData) = 0x0f bu değerler aşağıda tanımlandı ama global olarak tanımlanabilir
    #float(yPRData) = 0x0f
    #try:
    x_MmToPulse = GetX_mmToPulse()
    y_MmToPulse = GetY_mmToPulse()
    x_DilHomeRef = GetDilX_HomeRef() #68
    y_DilHomeRef = GetDilY_HomeRef() #-1680
    print("Satır 342   ")
        
    coordinateRefPoint = GetCoordinateRefPoint()
    
    referanceErrorX = False
    referanceErrorY = False
       
    """if coordinateRefPoint == "A":  
        if (x_DilHomeRef < -500 or x_DilHomeRef > 300):
            print("351")
            referanceErrorX = True
        if (y_DilHomeRef < -1250 or y_DilHomeRef > -1900):
            print("354")
            referanceErrorY = True
        print("satır 356")   
        
    elif coordinateRefPoint == "B":
        if (x_DilHomeRef < -500 or x_DilHomeRef > 300):
            referanceErrorX = True
            
        if (y_DilHomeRef < -500 or y_DilHomeRef > 300):
            referanceErrorY = True
            
        
    elif coordinateRefPoint == "C":
        if (x_DilHomeRef > -1500 or x_DilHomeRef < -2250):
            referanceErrorX = True
              
        if (y_DilHomeRef < -500 or y_DilHomeRef > 300):
            referanceErrorY = True
            
        
    elif coordinateRefPoint == "D":
        if (x_DilHomeRef > -1500 or x_DilHomeRef < -2250):
            referanceErrorX 
             
        if (y_DilHomeRef > -1250 or y_DilHomeRef < -1900):
            referanceErrorY"""
    


    print("375")
        #sürekli almasın , eğer -1 ise değiştir
    shortMovementThreshold = GetShortMovementValue()

        #if (!referanceErrorX && !referanceErrorY) \\REF POINT SIRALAMASI DÜZELECEK..
     #if True
            #EBOT boyutu ile referans bilgileri uyumlu 
            #burada C# ta iki tane y_DilHomeRef var. X olarak düzeltildi.
            #print("Satır : 381")
    if (x_MmToPulse != -1 and y_MmToPulse != -1 and x_DilHomeRef != -1 and y_DilHomeRef != -1):
                #referans noktaları belirlendi

        print("Satır : 384")
        a = 5
        if a==5 or (shelfID != PreDefinedShelf.WAIT and shelfID != PreDefinedShelf.DROP_LOC_1 and shelfID != PreDefinedShelf.DROP_LOC_2 and shelfID != PreDefinedShelf.DROP_LOC_3 and shelfID != PreDefinedShelf.DROP_LOC_4) :
                    #EBOT üzerinde bir göz seçildi
                    #EbotShelf ORM dosyasında DataBase iletişimi sağlayan bir yapı
            
            relatedShelf = EbotShelf.objects.get(id=shelfID) #BURASI SHELFID NIN BELİRSİZLİĞİNDEN DOLAYI ÇALIŞMAYABİLİR BİR EŞİTLİK GEREKİYOR
            print("Satır : 390")
            print(relatedShelf.xDeltaPosition)
            if relatedShelf != None:
                xPositionToMove = relatedShelf.xPositionAbs + relatedShelf.xDeltaPosition
                yPositionToMove = relatedShelf.yPositionAbs + relatedShelf.yDeltaPosition
                print("x ve y" , xPositionToMove , yPositionToMove)    #SQL den doğrudan alınan veri     
                xPRData = 0x0F #DATA dan gelen veriler 
                yPRData = 0x0F #C#ta 0.0f şeklinde
                print("Satır : 397")    
                print(y_DilHomeRef)
                if coordinateRefPoint == "A":
                    xPRData = (x_DilHomeRef - xPositionToMove) * x_MmToPulse # (68-1000) * 3125 = -2.912.500
                    yPRData = (y_DilHomeRef + yPositionToMove) * y_MmToPulse # (-16801000) * 3125 = -8.375.00 / -2.125.000
                    print("Satır: 401 / cabın A")
                    print(xPRData , yPRData)

                elif coordinateRefPoint == "B":
                    xPRData = (x_DilHomeRef - xPositionToMove) * x_MmToPulse
                    yPRData = (y_DilHomeRef - yPositionToMove) * y_MmToPulse

                elif coordinateRefPoint == "C":
                    xPRData = (x_DilHomeRef + xPositionToMove) * x_MmToPulse
                    yPRData = (y_DilHomeRef - yPositionToMove) * y_MmToPulse

                elif coordinateRefPoint == "D":
                    xPRData = (x_DilHomeRef + xPositionToMove) * x_MmToPulse
                    yPRData = (y_DilHomeRef + yPositionToMove) * y_MmToPulse

                print("427")               
                print(xPRData)  
                print(yPRData)        
                X_Curr_Pos = X_CurrentPosition() #EbotOperations class yapılabilir
                print("430")

                if (shortMovementThreshold != -1): #buraya giriyor
                    print("456")
                    if (abs(xPRData - X_Curr_Pos) < 200000): #buraya giriyor
                        shortMovement = True
                        print("459")
                    else:
                        shortMovement = False
                        print("462")
                else:
                    shortMovement = False
                    print("465")
                if (shortMovement == True ):
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_05, Convert2WriteInt32(int(xPRData)))
                    print(Convert2WriteInt32(int(xPRData)))
                    
                else:
                    b=ModBusRead(axisX , ServoDriveParameters.P06_05 , 2)
                    print("data değişmeden hemen önce " ,b)
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_03,Convert2WriteInt32(int(xPRData)))
                    a=ModBusRead(axisX , ServoDriveParameters.P06_05 , 2 )
                    c = ModBusRead(axisX , ServoDriveParameters.P06_03 , 2 )
                    
                    print("selam canım ", a ,c , xPRData , yPRData )
                    print("convertten sonra " , Convert2WriteInt32(int(xPRData)))
                    print("474")
                ModBusWriteMultiple(axisY, ServoDriveParameters.P06_03, Convert2WriteInt32(int(yPRData)))
                print("475")
                return True
            else:
                print("Göz Pozisyon Bilgisi Alınamadı") #import logging
                return False         
        else:
            print("493")
            servicePointCoordinates=GetservicePointCoordinates()#BURDAN İKİLİ BİR ARRAY GELİYOR 4/5 KERE GELİP BAŞKA BİR ARRAYE TEK TEK ATANMALI 
            #servicePoint=[0,0]
                    #Ön Tanımlı Pozisyonlar 
            if (shelfID == PreDefinedShelf.WAIT): #PREDEFINEDSHELF = 0 
                xPRData = 0x0F #veri tabanından alınacak 
                yPRData = 0x0F #veri tabanından alınacak

                X_Curr_Pos = X_CurrentPosition()

                if (shortMovementThreshold != -1):
                    if (abs(xPRData - X_Curr_Pos) < 200000):
                        shortMovement = True
                    else:
                        shortMovement = False
                else:
                    shortMovement = False
                        
                if (shortMovement):
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_05, Convert2WriteInt32(int(xPRData)))
                else:
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_03, Convert2WriteInt32(int(xPRData)))
                        
                ModBusWriteMultiple(axisY, ServoDriveParameters.P06_03, Convert2WriteInt32(int(yPRData)))
                print("508")
                return True
                    
            elif (shelfID != int(PreDefinedShelf.DROP_LOC_1)):
                        #Veri tabanından alınacak şimdilik tahmini konumlar seçildi
                        ##servicePointCoordinates'te bir array
                 
                print("524")   
                print(servicePointCoordinates)                         
                servicePoint = servicePointCoordinates[0]
                print(servicePoint)
                xPRData = servicePoint[0] * (x_MmToPulse)
                print(xPRData)
                yPRData = servicePoint[1] * (y_MmToPulse)
                print(yPRData)
                print("528")
                        
                X_Curr_Pos = X_CurrentPosition()

                if(shortMovementThreshold != -1):
                    if (abs(xPRData - X_Curr_Pos) < 200000):
                        shortMovement=True
                    else:
                        shortMovement=False
                else:
                    shortMovement=False
                if (shortMovement):
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_05, Convert2WriteInt32(int(xPRData)))

                else:
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_03, Convert2WriteInt32(int(xPRData)))
                        
                ModBusWriteMultiple(axisY, ServoDriveParameters.P06_03, Convert2WriteInt32(int(yPRData)))

                return True
                        
            elif (shelfID == int(PreDefinedShelf.DROP_LOC_2)):
                        #Veri tabanından alınacak şimdilik tahmini konumlar seçildi
                        
                servicePoint = servicePointCoordinates[1]
                xPRData = servicePoint[0] * (x_MmToPulse)
                yPRData = servicePoint[1] * (y_MmToPulse)
                        
                X_Curr_Pos = X_CurrentPosition()

                if(shortMovementThreshold != -1):
                    if (abs(xPRData - X_Curr_Pos) < 200000):
                        shortMovement=True
                    else:
                        shortMovement=False
                else:
                    shortMovement=False
                if (shortMovement):
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_05, Convert2WriteInt32(int(xPRData)))

                else:
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_03, Convert2WriteInt32(int(xPRData)))
                        
                ModBusWriteMultiple(axisY, ServoDriveParameters.P06_03, Convert2WriteInt32(int(yPRData)))

                return True

            elif (shelfID == int(PreDefinedShelf.DROP_LOC_3)):
                        #Veri tabanından alınacak şimdilik tahmini konumlar seçildi
                        
                servicePoint = servicePointCoordinates[2]
                xPRData = servicePoint[0] * (x_MmToPulse)
                yPRData = servicePoint[1] * (y_MmToPulse)
                        
                X_Curr_Pos = X_CurrentPosition()

                if(shortMovementThreshold != -1):
                    if (abs(xPRData - X_Curr_Pos) < 200000):
                        shortMovement=True
                    else:
                        shortMovement=False
                else:
                    shortMovement=False
                if (shortMovement):
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_05, Convert2WriteInt32(int(xPRData)))

                else:
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_03, Convert2WriteInt32(int(xPRData)))
                        
                ModBusWriteMultiple(axisY, ServoDriveParameters.P06_03, Convert2WriteInt32(int(yPRData)))

                return True

            elif (shelfID == int(PreDefinedShelf.DROP_LOC_4)):
                        #Veri tabanından alınacak şimdilik tahmini konumlar seçildi
                        
                servicePoint = servicePointCoordinates[3]
                xPRData = servicePoint[0] * (x_MmToPulse)
                yPRData = servicePoint[1] * (y_MmToPulse)
                        
                X_Curr_Pos = X_CurrentPosition()

                if(shortMovementThreshold != -1):
                    if (abs(xPRData - X_Curr_Pos) < 200000):
                        shortMovement=True
                    else:
                        shortMovement=False
                else:
                        shortMovement=False
                if (shortMovement):
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_05, Convert2WriteInt32(int(xPRData)))

                else:
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_03, Convert2WriteInt32(int(xPRData)))
                        
                ModBusWriteMultiple(axisY, ServoDriveParameters.P06_03, Convert2WriteInt32(int(yPRData)))

                return True

            elif (shelfID == int(PreDefinedShelf.DROP_LOC_5)):
                        #Veri tabanından alınacak şimdilik tahmini konumlar seçildi
                        
                servicePoint = servicePointCoordinates[4]
                xPRData = servicePoint[0] * (x_MmToPulse)
                yPRData = servicePoint[1] * (y_MmToPulse)
                        
                X_Curr_Pos = X_CurrentPosition()

                if(shortMovementThreshold != -1):
                    if (abs(xPRData - X_Curr_Pos) < 200000):
                        shortMovement=True
                    else:
                        shortMovement=False
                else:
                    shortMovement=False
                if (shortMovement):
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_05, Convert2WriteInt32(int(xPRData)))

                else:
                    ModBusWriteMultiple(axisX, ServoDriveParameters.P06_03, Convert2WriteInt32(int(xPRData)))
                        
                ModBusWriteMultiple(axisY, ServoDriveParameters.P06_03, Convert2WriteInt32(int(yPRData)))
                print("599")
                return True
            else:
                print("602")
                return False
    else:
         
        print("Hareket parametlerine ulaşılamadı.")
        return False
#else:
 #   print("Referans parametreleri hatalı. İşlemin devam etmesi fiziksel limitlerin aşılmasına sebep olabileceğinden devam edilmiyor. Lütfen referans noktalarını kontrol ediniz." )    
  #  return False
    #finally:
        #print("Ebot Hareketi ile ilgili parametlerin yazımı sırasında hata oluştu.")
        #return False

    


def GetComPort485FromDb():
    name = EbotParameters.objects.get(paramName = 'COMPORT_485')
    value = name.paramValue
    return value

def CheckAuxFunction():
    auxFunctionX = ModBusRead(axisX , ServoDriveParameters.P02_30 , 1)
    auxFunctionY = ModBusRead(axisY , ServoDriveParameters.P02_30 , 1)
    if auxFunctionX[0] != ServoDriveData.EEPROM_DSBL:
        ModBusWriteSingle(axisX , ServoDriveParameters.P02_30 , ServoDriveData.EEPROM_DSBL)
    if auxFunctionY[0] != ServoDriveData.EEPROM_DSBL:
        ModBusWriteSingle(axisY , ServoDriveParameters.P02_30 , ServoDriveData.EEPROM_DSBL)

def CheckServoON():
    servoOnX = ModBusRead(axisX , ServoDriveParameters.P02_10 , 1)
    servoOnY = ModBusRead(axisY , ServoDriveParameters.P02_10 , 1)
    if servoOnX[0] != ServoDriveData.SRV_ON:
        ModBusWriteSingle(axisX , ServoDriveParameters.P02_10 , ServoDriveData.SRV_ON)
    if servoOnY[0] != ServoDriveData.SRV_ON:
        ModBusWriteSingle(axisY , ServoDriveParameters.P02_10 , ServoDriveData.SRV_ON)


def InitServoDriveComm():
    instrument = minimalmodbus.Instrument('COM5',4) #COM , SLAVE
    ComPort485 = ""
   # try:
        #if instrument.serial.is_open():
            #if ComPort485 == "":  #None
                #ComPort485 = GetComPort485FromDb()
            
    instrument.serial.port              # this is the serial port name
    instrument.serial.baudrate = BAUDRATE         # Baud
    instrument.serial.bytesize = 8
    instrument.serial.parity   = serial.PARITY_NONE
    instrument.serial.stopbits = 2
    instrument.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
    instrument.clear_buffers_before_each_transaction = True
            
    #instrument.serial.open() #Questo posto sarà controllato!!! 
            
            #burada else if vardı yazmadık 

    #CheckAuxFunction()
    #CheckServoON()
        #return True
    #except:
       # print("Servo Hazırlık Aşamasında Hazırlık Oluştu ")
        #return False

            

def AllPositionCompleted(PR_X , PR_Y):
    posCompX = ModBusRead(axisX , ServoDriveParameters.P05_07 , 1)
    posCompY = ModBusRead(axisY , ServoDriveParameters.P05_07 , 1)    
    return (posCompX[0] == 20000 + PR_X) and (posCompY[0] == 20000 + PR_Y) 
    


def MoveToPosition(shelfID):
   
    shortMovement = False #bunu normalde PreparePrTo moveun parametresi olarak almalıyız ama biz fixedledik
    #if InitServoDriveComm():
    if shelfID != PreDefinedShelf.HOMING:
        a=5
        if a==5:#PrepareToMove(shelfID):
            PreparePrToMove(shelfID)
            #try:
            print("722")
            if (shortMovement == True ) :
                ModBusWriteSingle(axisX, ServoDriveParameters.P05_07, ServoDriveData.PR02)
                print("726")
            else:
                ModBusWriteSingle(axisX, ServoDriveParameters.P05_07, ServoDriveData.PR01)
            ModBusWriteSingle(axisY, ServoDriveParameters.P05_07, ServoDriveData.PR01)
            counter=0
            countLimit=TIME_OUT_IN_LOOP 
            if (shortMovement == True):
                print("733")
                while AllPositionCompleted(ServoDriveData.PR02, ServoDriveData.PR01) is not True:
                    
                    currentStatus=GetEbotElectricalStatus() # currentstatus ve mkk yapılacak
                    """ES_24V = str(GetElectricalStatus[1])
                    ES_12V = str(GetElectricalStatus[2])
                    ES_5V = str(GetElectricalStatus[3])
                    ES_EMGS = str(GetElectricalStatus[4])
                    ES_COV_CLS = str(GetElectricalStatus[5]) 
                    ES_COV_OPN = str(GetElectricalStatus[6])
                    ES_DIL_FWD = str(GetElectricalStatus[7])
                    ES_DIL_REV = str(GetElectricalStatus[8]) 
                    ES_ILC_INP = str(GetElectricalStatus[9])"""
                    if currentStatus!=None:
                        if currentStatus[1] != True or currentStatus[4] == True:
                            print("EMGS Stop Aktif!")
                            return shelfID
                    counter+=1
                    if counter>countLimit:
                        print("Servo hareket tamamlandı bilgisi alınırken zaman aşımı doldu. Servo alarm durumunu kontrol edin.")
                        return False
            else:
                while AllPositionCompleted(ServoDriveData.PR01 , ServoDriveData.PR02) != True:
                    currentStatus = True #MKK_Communication.GetEbotElectricalStatus()
                    if currentStatus!=None:
                        a=5
                        if a==5: #currentStatus[1] != True or currentStatus[4] == True:
                            print("EMGS Stop Aktif!")
                            return False
                    counter+=1
                    if counter>countLimit:
                        print("Servo hareket tamamlandı bilgisi alınırken zaman aşımı doldu. Servo alarm durumunu kontrol edin.")
                        return False
            return True
            #except:
                #print("Ebot hareketi sırasında hata oluştu.")
                #return False
        else:
            return False
    else:
        print("HOMING STARTED!")
        ModBusWriteSingle(axisX, ServoDriveParameters.P05_07, ServoDriveData.HOME)
        ModBusWriteSingle(axisY, ServoDriveParameters.P05_07, ServoDriveData.HOME)
        counter=0
        countLimit = TIME_OUT_IN_LOOP
        while AllPositionCompleted(ServoDriveData.HOME):
            print("768")
            currentStatus = True #MKK_Communication.GetEbotElectricalStatus()
            if currentStatus!=None:
                if currentStatus.ES_24V!=True or currentStatus.ES_EMGS==True:
                    print("EMGS Stop Aktif!")
                    return False
            counter+=1
            if counter>countLimit:
                print("Servo hareket tamamlandı bilgisi alınırken zaman aşımı doldu. Servo alarm durumunu kontrol edin.")
                return False
        print("HOMING FINISHED!")
        return True
    #else:
        #return False


#MKK VE CURRENT STATUS FİXED

def XHome():
    #Yasin Gülsüm
    #if (InitServoDriveComm()):
    print("X HOME STARTED!")

    ModBusWriteSingle(axisX, ServoDriveParameters.P05_07, ServoDriveData.HOME)
    counter = 0
    countLimit = int(TIME_OUT_IN_LOOP/TIME_TO_WAIT)
    while (AllPositionCompleted(axisX, ServoDriveData.HOME) != False):
        #CONTROLLA QUI !!!!
        currentStatus = True #MKK_Communication.GetEbotElectricalStatus():
        if (currentStatus != None):
            if (currentStatus.ES_24 != True and currentStatus.ES_EMGS == True ):
                print("EMG Stop Aktif!")
                return False
        
        counter += 1

        if (counter > countLimit):
            logging.error("Servo hareket tamamlandı bilgisi alınırken zaman aşımı doldu. Servo alarm durumunu kontrol edin.")
            return False
    print("X HOME FINISHED!")
    return True
    #else: 
     #   return False
    
def YHome():
    #Yasin Gülsüm
    #if (InitServoDriveComm()):
    print("Y HOME STARTED!")

    ModBusWriteSingle(axisY, ServoDriveParameters.P05_07, ServoDriveData.HOME)
    counter = 0
    countLimit = int(TIME_OUT_IN_LOOP/TIME_TO_WAIT)
    while (AllPositionCompleted(axisY, ServoDriveData.HOME) != False):
        #CONTROLLA QUI !!!!
        currentStatus = True #MKK_Communication.GetEbotElectricalStatus():
        if (currentStatus != None):
            if (currentStatus.ES_24 != True and currentStatus.ES_EMGS == True ):
                print("EMG Stop Aktif!")
                return False
        
        counter += 1

        if (counter > countLimit):
            logging.error("Servo hareket tamamlandı bilgisi alınırken zaman aşımı doldu. Servo alarm durumunu kontrol edin.")
            return False
    print("Y HOME FINISHED!")
    return True
    #else: 
    #    return False

from .Mkk_Communications import *


def DilForward():
    receivedMessage = None
    receivedMessage = SendMkk(MessageStructureClass.CMD_DIL_FWD) # Mkk dosyasını kullanacaksak böyle gönderilmeli
    
    if receivedMessage == None:
        if len(receivedMessage) > 0:
            sonuc = receivedMessage#.lastbyte
            if sonuc[0] == 0x99:
                print("Dil ileride")
                return True 
            else:
                return False
        else:
            return False
    else:
        return False


def DilReverse():
    receivedMessage = None
    receivedMessage = SendMkk(MessageStructureClass.CMD_DIL_REV) # Mkk dosyasını kullanacaksak böyle gönderilmeli
    
    if receivedMessage == None:
        if len(receivedMessage) > 0:
            sonuc = receivedMessage#.lastbyte
            if sonuc[0] == 0x99:
                print("Dil Geride")
                return True 
            else:
                return False
        else:
            return False
    else:
        return False



def CoverOpen():
    receivedMessage = None
    receivedMessage = SendMkk(MessageStructureClass.CMD_COV_OPN)
    if receivedMessage == None:
        if len(receivedMessage) > 0:
            sonuc = receivedMessage#.lastbyte
            if sonuc[0] == 0x99:
                print("Kapak Açık")
                return True 
            else:
                return False
        else:
            return False
    else:
        return False
    
def CoverClose():
    receivedMessage = None
    receivedMessage = SendMkk(MessageStructureClass.CMD_COV_CLS)

    if receivedMessage == None:
        if len(receivedMessage) > 0:
            sonuc = receivedMessage#.lastbyte
            if sonuc[0] == 0x99:
                print("Kapak Kapalı")
                return True 
            else:
                return False
        else:
            return False
    else:
        return False
    

def GetMedicineRoutine():
    ModBusWriteSingle(axisY, ServoDriveParameters.P05_07, ServoDriveData.PR62)
    if DilForward == 0 :
        if(ilcReceivedStatus== True):
            print("Ilac Alındı Bilgisi Dil İleri Hareketi Sonrası Resetlendi.")
        else:
            print("HATA - Ilac Alındı Bilgisi Dil İleri Hareketi Sonrası Resetlenemedi.")
        for i in range(4):
            ModBusWriteSingle(axisY, ServoDriveParameters.P05_07, ServoDriveData.PR62)
            counter=0
            countLimit=TIME_OUT_IN_LOOP / TIME_TO_WAIT
            #PR62 veya PR63 olacak Debug et..
            while PositionCompleted(axisY, ServoDriveData.PR63) == False:
                currentStatus = GetEbotElectricalStatus()
                if currentStatus!= None:
                    if currentStatus.ES_24V==0 or currentStatus.ES_EMGS == 1:
                                
                        print("EMGS Stop Aktif!")
                counter+=1
                if (counter > countLimit):
                    print("Y ekseni hareket tamamlandı bilgisi alınırken zaman aşımı süresi doldu. Servo alarm durumunu kontrol edin. Dil otomatik olarak geri alınacaktır.")
                    DilReverse()
            if ilcReceivedStatus == False:   # c#dan bak buraya.
            
                print("Ilac Giris Sensorunden ilaç alındı bilgisi okundu.")
                if ilcReceivedStatus== True:
                    print("Ilac Giris Flag resetlendi.")
                else:
                    print("Ilac Giris Flag resetlenemedi.")
                break

#ILAC GIRIS DEGISKENINI KONTROL ET  

        if DilReverse== True:
        
            return True
        else:
            return False
    else:
        return False




def DropMedicineRoutine():
    # try catch vardı yazmadım
    if CoverOpen == True:
        if CoverClose == True:
            
            return True
        else:
            return False
    else:
        return False
# C# ta buraya log yazılıyordu



def PositionCompleted(_slaveID, _PR):
    posComp = ModBusRead(_slaveID, ServoDriveParameters.P05_07, 1)
    return (posComp[0] == 20000 + _PR)
