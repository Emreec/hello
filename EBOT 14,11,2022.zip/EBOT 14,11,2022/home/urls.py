from django.urls import path 
from . import views
from django.contrib.auth import views as auth_views

urlpatterns=[
    path('login/',views.LoginUser,name='login'),
    path('logout/',views.LogoutUser,name='logout'),
    path('register/',views.RegisterUser,name='register'),
    path('delete/<str:pk>',views.DeleteUser,name='delete'),
    path('password/',auth_views.PasswordChangeView.as_view(template_name="home/ChangePassword.html"),name='password'),
    
    
    

    path('',views.home,name='home'),
    #path('usersSettings/',views.UserSettings,name='userSettings'),
    path('users/<str:pk>/',views.users,name='users'),
    path('parameters/',views.parameters,name='parameters'),
    path('EbotManual/',views.EbotManual,name='EbotManual'),
    path('LedManual/',views.LedManual,name='LedManual'),
    path('TestRutins/',views.TestRutins,name='TestRutins'),




   
    path('parameters1/',views.parameters1 , name ='parameters1'),

    path('movetoposition/' , views.MoveToPositionMain , name='MoveToPosition'),
    path('homex/', views.HomeXMain , name='HomeX'),
    path('homey/', views.HomeYMain , name='HomeY'),
    path('dilforward/', views.DilForwardMain , name ="DilForward"),
    path('dilreverse/', views.DilReverseMain , name ="DilReverse"),
    path('coveropen/', views.CoverOpenMain , name = "CoverOpen"),
    path('coverclose/', views.CoverCloseMain , name = "CoverClose"),
    path('checkstatus/',views.GetEbotElectricalStatusMain , name = 'ElectricalStatus'),
    path('movetonext/',views.MoveToNextShelfMain , name = 'MoveToNextShelf'),
    path('movetoprevious/',views.MoveToPreviousShelf , name = 'MoveToPreviousShelf'),
    path('getmedicine/',views.GetMedicineRoutineMain , name = 'GetMedicineRoutine'),

    #for the final project
    path('movetomedicine/',views.MoveToMedicineMain , name = 'MoveToMedicine'),
    path('uploadmedicine/',views.MoveToUploadMedicine , name = 'MoveToUploadMedicine'),
  
]