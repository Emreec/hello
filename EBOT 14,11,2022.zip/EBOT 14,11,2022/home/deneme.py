
CMD_DIL_FWD=  0x20
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User

from users.models import DataEbotUser
from .forms import CustomUserCreationForm, EditUserForm 
from django.contrib.auth.forms import UserChangeForm
from django.contrib import messages


from Domain.models import *
from MedicineData.models import *
from EbotShelf.models import *


import logging


import minimalmodbus
import serial


class MessageStructureClass():
    SF = 0xAB
    FB = 0x02
    EF = 0xFB

    SUCCESS = 0x99
    FAIL = 0x98
    ERR_TO = 0x94
    ERR_UNKCMD = 0x93
    ERR_MSG = 0x92
    ERR_CSUM = 0x91

    ARD_PING = 0x05
    CH_24V = 0x10
    CH_12V = 0x11
    CH_5V = 0x12
    CH_EMGS = 0x13
    CH_COV_OPN = 0x14
    CH_COV_CLS = 0x15
    CH_DIL_FWD = 0x16
    CH_DIL_REV = 0x17
    CH_ILC_INP = 0x18
    CH_ALL = 0x19

    CMD_DIL_FWD = 0x20
    CMD_DIL_REV = 0x21
    CMD_COV_OPN = 0x22
    CMD_COV_CLS = 0x23

    CMD_LED = 0x30
    CMD_TEST_LED0 = 0x31
    CMD_FRONT_LED = 0x32
    CMD_ALL_OFF = 0x33


TIME_OUT_RECEIVE = 3000
TIME_TO_WAIT = 50

IpAddressMkk = ""
PortMkk = 0
ComPortMkk = ""


