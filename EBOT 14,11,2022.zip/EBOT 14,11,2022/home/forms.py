from django.forms import ModelForm 
from django.contrib.auth.models import User 
from django.contrib.auth.forms import UserCreationForm ,UserChangeForm 
from django import forms
from users.models import DataEbotUser
 

class CustomUserCreationForm(UserCreationForm):
    first_name=forms.CharField(max_length=200)
    last_name=forms.CharField(max_length=200)
    email=forms.EmailField()
    phone=forms.CharField(max_length=11)
    
    class Meta:
        model = DataEbotUser 
        fields = ['username','first_name','last_name','email','phone','password1','password2']
    
    def __init__(self, *args, **kwargs):
        super(UserCreationForm, self).__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Enter username...'})
        self.fields['first_name'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Enter First Name...'})
        self.fields['last_name'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Enter Last Name ...'})
        self.fields['email'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Enter Email...'})
        self.fields['phone'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Enter Phone...'})
        self.fields['password1'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Enter password...'})
        self.fields['password2'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Confirm password...'})
        

    
class EditUserForm(ModelForm):
    class Meta:
        model = DataEbotUser 
        fields = ['username','first_name','last_name','email','phone','last_login','date_joined']

    def __init__(self, *args, **kwargs):
        super(EditUserForm, self).__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Kullanıcı Adını Girin...'})
        self.fields['first_name'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'İsim Girin...'})
        self.fields['last_name'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Soyisim Girin ...'})
        self.fields['email'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Email Girin...'})
        self.fields['phone'].widget.attrs.update(
            {'class': 'form-control', 'placeholder': 'Telefon Numarası Girin...'})
        self.fields['last_login'].widget.attrs.update(
            {'class': 'form-control'})
        self.fields['date_joined'].widget.attrs.update(
            {'class': 'form-control'})

    def __str__(self):
        return self.username
        
                

        

