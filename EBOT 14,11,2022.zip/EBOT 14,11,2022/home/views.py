

from http.client import OK
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
#from home.MKK_Communications import MessageStructureClass
from users.models import DataEbotUser
from .forms import CustomUserCreationForm, EditUserForm 
from django.contrib.auth.forms import UserChangeForm
from django.contrib import messages


from Domain.models import *
from MedicineData.models import *
from EbotShelf.models import *
from MedicineModel.models import *
from UploadMedd.models import *

import logging


import minimalmodbus
import serial
# Create your views here.

######### Buradan itibaren değer atamaları vardır ########

axisX = 0X01
axisY = 0X7F




TIME_OUT_IN_LOOP = 10000; #10sn bekleme
TIME_BTW_MODBUS_CMD = 20; #Modbus Komutları Arasında Bekleme sabiti - 50ms - 25ms sorunsuz idi
TIME_TO_DROP_MEDICINE = 1500; # Kapak açıkken bekleme sabiti
TIME_BTW_TRY = 250; #İlaç alma sırasında alamaz ise bekleme sabiti
TIME_TO_WAIT = 20; #Genel bekleme sabiti
BAUDRATE = 115200; #RS485 BAUD RATE

class PreDefinedShelf():
    WAIT = 0
    DROP_LOC_1 = -1    
    DROP_LOC_2 = -2
    DROP_LOC_3 = -4
    DROP_LOC_4 = -5 
    DROP_LOC_5 = -6
    DROP_LOC_6 = -7
    DROP_LOC_7 = -8
    DROP_LOC_8 = -9
    DROP_LOC_9 = -10
    DROP_LOC_10 = -11
    HOMING = -3


class ServoDriveParameters():
    P00_01 = 0x0002   #Alarm Status
    P00_09 = 0x0012   #Input pulse command value
    P00_10 = 0x0014   #Servo Status
    P00_11 = 0x0016   #Digital Input Status
    P00_12 = 0x0018   #Digital out status
    P00_13 = 0x001A   #IGBT Temprature

    P02_10 = 0x0214   #DI1 - Servo On
    P02_30 = 0x023C   #AUX Function
    P05_07 = 0x050E   #Comm PR Trigger
    P06_03 = 0x0606   #Path1 Data
    P06_05 = 0x060A   #Path2 Data #shortmovement la beraber Y de kısa hareketi anlatıyor
    P06_07 = 0x060E   #Path3 Data
    P06_09 = 0x0612   #Path4 Data
    P06_11 = 0x0616   #Path5 Data



class ServoDriveData():
    HOME = 0x0000
    SRV_ON = 0x0001
    SRV_OFF = 0x0101
    EEPROM_DSBL = 0x0005
    PR01 = 0x0001 
    PR02 = 0x0002 
    PR03 = 0x0003 
    PR04 = 0x0004 
    PR05 = 0x0005 
    PR62 = 0x003E #EBOTUN haznenin ilacı alma amacıyla yukarı doğru hareket etmesi
    PR63 = 0x003F #EBOTUN haznenin aşağıya belli bir mesafe gitmesi
    STOP = 0x03E8
    




def LoginUser(request):
    page='login'
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(request,username=username,password=password)

        if user is not None:
            login(request,user)
            return redirect('home')

    return render(request,'home/LoginRegister.html',{'page':page})


def LogoutUser(request):
    logout(request)
    return redirect('login')


def RegisterUser(request):
    page='register'
    form=CustomUserCreationForm()
    
    if request.method=='POST':
        form=CustomUserCreationForm(request.POST)
        if form.is_valid():
            user=form.save(commit=False)
            user.save()
            messages.success(request,"User added")
            user=authenticate(request,username=user.username,password=request.POST['password1'])


    context={'form':form,'page':page}
    return render(request,'home/RegisterPage.html',context)

def DeleteUser(request,pk):
    user=DataEbotUser.objects.get(id=pk)
    user.delete()
    messages.success(request,"User deleted")
    context={'user':user}
    return redirect('home')



    
    

@login_required(login_url='login') #Created a login requirement for the below functions 
def home(request):
    return render(request,'home/HomePage.html')

@login_required(login_url='login')
def users(request,pk):  #users keeps all the user models which exists in database to prthem one by one to the page 
    user=DataEbotUser.objects.get(id=pk)#user keeps only the requested user to work on specific information of one user
    form=EditUserForm(instance=user)
    users=DataEbotUser.objects.all()
    
    
    if request.method=='POST':
        form=EditUserForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request,"User Updated")

            
                    
    
    context={'form':form , 'users':users , 'user':user}
    return render(request,'home/UsersPage.html',context)

def medicine_list(request):
    medicines = MedicineModel.objects.get(MedName = "Arveles") 
 

    return render(request, 'home/EbotManual', {'medicines': medicines})

def parameters1(request): #FİLTER SADECE İSTENİLEN BİLGİYİ ALIR
    #shelf=EbotShelf.objects.get(id)
    shelfs = EbotParameters.objects.get()
    
    for i in shelfs:
        i.paramName == "SERVICE_POINT"
        info=i.paramValue
            
    shelfID = request.POST.get("shelfID")
    print(shelfID)
   # param = EbotParam.objects.all()

    context = {'shelfs':shelfs , 'info':info  , "shelfID" : shelfID}
    return render(request , 'home/Deneme.html' , context)
    




@login_required(login_url='login')
def parameters(request):
    return render(request,'home/Parameters.html')




@login_required(login_url='login')
def EbotManual(request):
    medicines = MedicineModel.objects.all()
    print(medicines)
    context = {'medicines': medicines}
    return render(request, 'home/EbotManual.html', context)
    




@login_required(login_url='login')
def LedManual(request):
    return render(request,'home/LedManual.html')




@login_required(login_url='login')
def TestRutins(request):
    return render(request,'home/TestRutins.html')





#############################################BURADAN AŞAĞIDA OPERATION FONKSYONLARI BULUNMAKTADIR#####################################################
from .EBOT_Operations import *

shelfID = 3 
def MoveToPositionMain(request): #burada da id yi fixedledik çünkü id yi nereden alacagımızı bilmiyoruz 
    global shelfID
    
    shelfID = request.POST.get("shelfID")

    print(shelfID)
    

    if request.method != "POST" :
        shelfID = PreDefinedShelf.HOMING #Burada başka bir ihtimal gerekirse değişiklik lazım 
        
    
    MovePosition = MoveToPosition(shelfID)

    context = {'MovePosition' : MovePosition}
    return  render(request , 'home/EbotManual.html', context) 


MedName = "A"
def MoveToMedicineMain(request):
    MedName = request.POST.get("MedName")
    print(MedName)
    medicines = MedicineModel.objects.all()

    if request.method!="POST":
        print("Undefined Medicine Name")
    MoveMedicine = MoveToMedicine(request , MedName)

    if MoveMedicine == 0:
        error_message = "Medicine Does Not Exist In The System! Please Check The Name."
        return render(request, 'home/EbotManual.html', {'error_message': error_message , 'medicines': medicines })
    
    elif MoveMedicine == 1:
        error_message = "Medicine Out Of Stock "
        return render(request, 'home/EbotManual.html', {'error_message': error_message , 'medicines': medicines })

    
    print(medicines)
    
    context = {'MoveMedicine' : MoveMedicine , 'medicines': medicines  }
    return render (request , 'home/EbotManual.html' , context)

def MoveToUploadMedicine(request):
    uMedNumber = request.POST.get("uploadShelfNumber")
    uMedName = request.POST.get("RegisterMedName")
    if request.method!="POST":
        print("Undefined Medicine Name")
    print(uMedNumber)
    medicines = MedicineModel.objects.all()
    uMoveMedicine = uMoveToMedicine(uMedNumber , uMedName) #function will be defined
    if uMoveMedicine == 0:
        error_message2 = "ALL SHELFS ARE FULL"
        return render(request, 'home/EbotManual.html', {'error_message2': error_message2 , 'medicines': medicines })
    elif uMoveMedicine == 1:
        error_message2 = "Fill The Required Blanks"
        return render(request, 'home/EbotManual.html', {'error_message2': error_message2 , 'medicines': medicines })
    context = {'uMoveMedicine' : uMoveMedicine , 'medicines': medicines}
    return render(request , 'home/EbotManual.html' , context )








def MoveToNextShelfMain(request):
    
    global shelfID
    if shelfID == -3:
        shelfID = 3 # BU NORMALDE 0 OLMALI AMA DATABASE BESTE DOLAYISIYLA HAZIR OLMADIĞINDAN YAPILAMADI
    shelfID = int(shelfID)+1 #küçük d li olan değiştirilmiş olandır
    print(shelfID)
    nextShelf = MoveToPosition(shelfID)
    context = {'nextShelf' : nextShelf}
    return render(request , 'home/EbotManual.html' , context)

def MoveToPreviousShelf(request):

    global shelfID 

    shelfID = int(shelfID)-1
    print(shelfID)
    previousShelf = MoveToPosition(shelfID)
    context = {'previousShelf' : previousShelf}
    
    return render(request , 'home/EbotManual.html' , context)


def uploadMed(request):
    return 0


def HomeXMain(request):
    HomeX = XHome()
    context = {'HomeX' : HomeX}
    return render(request , 'home/EbotManual.html', context)


def HomeYMain(request):
    HomeY = YHome()
    context = {'HomeY' : HomeY}
    return render(request , 'home/EbotManual.html', context)

"""def preparetest():
    ModBusWriteSingle(axisX, ServoDriveParameters.P05_07, ServoDriveData.PR01)
    ModBusWriteSingle(axisY, ServoDriveParameters.P05_07, ServoDriveData.PR01)

def PrepareMain(request):
    #shelfInfo = EbotShelf.objects.get(id=15)
    #shelfID = shelfInfo.id  
    shelfID = request.POST.get("shelfID")
    print(shelfID)
    print("883")
    PreparePrToMove(int(shelfID))
    
    Move = preparetest()
    context = {'Move' : Move }
    
    return render(request , 'home/EbotManual.html', context)"""



#################################################

def DilForwardMain(request):
    ForwardDil = DilForward()
    context = {"ForwardDil" : ForwardDil}
    
    return render(request , 'home/EbotManual.html', context)

def DilReverseMain(request):
    ReverseDil = DilReverse()
    context = {"ReverseDil" : ReverseDil}
    
    return render(request , 'home/EbotManual.html', context)

def CoverOpenMain(request):
    OpenCover = CoverOpen()
    context = {"OpenCover" : OpenCover}
    
    return render(request , 'home/EbotManual.html', context)

def CoverCloseMain(request):
    CloseCover = CoverClose()
    context = {"CloseCover" : CloseCover }
     
    return render(request , 'home/EbotManual.html', context)


def GetMedicineRoutineMain(request):
    GetMedicine=GetMedicineRoutine()
    context = {"GetMedicine": GetMedicine}
    return render(request, 'home/EbotManual.html', context)

def DropMedicineRoutineMain(request):
    DropMedicine=DropMedicineRoutine()
    context = {"DropMedicine": DropMedicine}
    return render(request, 'home/EbotManual.html', context)




def GetEbotElectricalStatusMain(request):
    GetElectricalStatus = GetEbotElectricalStatus()
    print(GetElectricalStatus)
    print(type(GetEbotElectricalStatus))
    if type(GetElectricalStatus) == list:
        ES_24V = str(GetElectricalStatus[1])
        ES_12V = str(GetElectricalStatus[2])
        ES_5V = str(GetElectricalStatus[3])
        ES_EMGS = str(GetElectricalStatus[4])
        ES_COV_CLS = str(GetElectricalStatus[5]) 
        ES_COV_OPN = str(GetElectricalStatus[6])
        ES_DIL_FWD = str(GetElectricalStatus[7])
        ES_DIL_REV = str(GetElectricalStatus[8]) 
        ES_ILC_INP = str(GetElectricalStatus[9])
    else: 
        print("hiçbir bok çalışmıyor")

    context = {"GetElectricalStatus" : GetElectricalStatus , "ES_24V" : ES_24V , 
    "ES_12V" : ES_12V , "ES_5V" : ES_5V ,  "ES_EMGS" : ES_EMGS ,  "ES_COV_CLS" : ES_COV_CLS,
    "ES_COV_OPN" : ES_COV_OPN , "ES_DIL_FWD" : ES_DIL_FWD ,"ES_DIL_REV" : ES_DIL_REV , "ES_ILC_INP" : ES_ILC_INP }
    return render(request , 'home/EbotManual.html' , context)



