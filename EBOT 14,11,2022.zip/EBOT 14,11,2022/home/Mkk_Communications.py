from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from users.models import DataEbotUser
from .forms import CustomUserCreationForm, EditUserForm 
from django.contrib.auth.forms import UserChangeForm
from django.contrib import messages


from Domain.models import *
from MedicineData.models import *
from EbotShelf.models import *


import logging


import minimalmodbus
import serial


class MessageStructureClass():
    SF = 0xAB
    FB = 0x02
    EF = 0xFB

    SUCCESS = 0x99
    FAIL = 0x98
    ERR_TO = 0x94
    ERR_UNKCMD = 0x93
    ERR_MSG = 0x92
    ERR_CSUM = 0x91

    ARD_PING = 0x05
    CH_24V = 0x10
    CH_12V = 0x11
    CH_5V = 0x12
    CH_EMGS = 0x13
    CH_COV_OPN = 0x14
    CH_COV_CLS = 0x15
    CH_DIL_FWD = 0x16
    CH_DIL_REV = 0x17
    CH_ILC_INP = 0x18
    CH_ALL = 0x19

    CMD_DIL_FWD = 0x20
    CMD_DIL_REV = 0x21
    CMD_COV_OPN = 0x22
    CMD_COV_CLS = 0x23

    CMD_LED = 0x30
    CMD_TEST_LED0 = 0x31
    CMD_FRONT_LED = 0x32
    CMD_ALL_OFF = 0x33


TIME_OUT_RECEIVE = 3000
TIME_TO_WAIT = 50

IpAddressMkk = ""
PortMkk = 0
ComPortMkk = ""

#class MKK_Communication():
#getter setter mantıgı daha iyi olabilir çalışması acısından 

def SendMkk(code): #socket aracılıgıyla mkk iletişiminin nasıl kuruldugunu bilmiyoruz
    
    ConnectMkk = True#ConnectToMkk()
    if ConnectMkk == True:
        instrument = minimalmodbus.Instrument(ComPortMkk, 1, debug=True)  # port name, slave address will be fixed 
        instrument.serial.port              # this is the serial port name
        instrument.serial.baudrate = 19200       # Baud
        instrument.serial.bytesize = 8
        instrument.serial.parity   = serial.PARITY_NONE
        instrument.serial.stopbits = 2
        instrument.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
        instrument.clear_buffers_before_each_transaction = True
        instrument.serial.timeout  = TIME_TO_WAIT
        
        instrument.write_register(2 , code , 0 )
        receivedMessage = RecieveMkk()
        return receivedMessage

    else :
        return None


def RecieveMkk():
    
    ConnectMkk = ConnectToMkk()
    if ConnectMkk == True:
        instrument = minimalmodbus.Instrument( ComPortMkk, 1, debug=True)  # port name, slave address (in decimal) # COM5 rastgele yazıldı 
        instrument.serial.port              # this is the serial port name
        instrument.serial.baudrate = 115200 #bunu farklı bir ölçüde almalıyız         # Baud
        instrument.serial.bytesize = 8
        instrument.serial.parity   = serial.PARITY_NONE
        instrument.serial.stopbits = 2
        instrument.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
        instrument.clear_buffers_before_each_transaction = True
        instrument.serial.timeout  = TIME_TO_WAIT
        #try: 
        print("283")
        resultSet = instrument.read_registers( 16 , 32) #Parametre adresi formatında bir okunamamazlık olabilir
        print(resultSet)
        return resultSet
    else:
        return None
        #burada parametre adresi hangi elemandan okunmaya başlayacaksa onu temsil ediyor            
#def SendReceiveLEDAkdeniz #gereksiz veya yazılım şekli farklı olmalı 






def pingMKK(): 
    

    instrument = minimalmodbus.Instrument(ComPortMkk, 1, debug=True)  # fixedlenmesi gerek zaten bitane var
    instrument.serial.port              # this is the serial port name
    instrument.serial.baudrate = 115200         # Baud
    instrument.serial.bytesize = 8
    instrument.serial.parity   = serial.PARITY_NONE
    instrument.serial.stopbits = 2
    instrument.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
    instrument.clear_buffers_before_each_transaction = True

    #spMkk.DtrEnable = True
    ping = None
    ping = instrument.read_register(32 , 0) #16 --> num of register to write // gerekmeyebilir tam anlamadım 

    #instrumentten alınan cevabın olumsuz olması durumunu modellememiz lazım 
    if ping== None:
        print("Mantık Kontrol Kartına PING erişimi sağlanamadı ")
    
    else:
        print("Erişim başarılı ")



def GetEbotElectricalStatus():
    
    receivedListFromMKK = SendMkk(MessageStructureClass.CH_ALL)
    
    if receivedListFromMKK != None:
        if len(receivedListFromMKK) > 0 :
            sonuc = receivedListFromMKK
            print(sonuc)
            print(type(sonuc))
            sonuc[0]= True
            sonuc[1] = True if sonuc[1] == 1 else False
            sonuc[2] = True if sonuc[2] == 1 else False
            sonuc[3] = True if sonuc[3] == 1 else False
            sonuc[4] = True if sonuc[4] == 1 else False
            sonuc[5]= True if sonuc[5] == 1 else False
            sonuc[6] = True if sonuc[6] == 1 else False
            sonuc[7] = True if sonuc[7] == 1 else False
            sonuc[8] = True if sonuc[8] == 1 else False
            sonuc[9] = True if sonuc[9] == 1 else False
            return sonuc 
        else:
            print("receivedList Count  <= 0")
            return None
    else:
        print("receivedList None")
        return None   



def commPingMkk():
    
    pingResult = SendMkk(MessageStructureClass.ARD_PING)

    if pingResult != None:
        if len(pingResult) > 0 :
            sonuc = pingResult
            if sonuc[0] == 0x99 and sonuc[1] == 0x05:
                return True
            else:
                return False
        else:
            return False
    else:
        return False


def ilcReceivedStatus(resetIlcFlag): #boolean
    
    if resetIlcFlag == False:
        ilcResult = SendMkk(MessageStructureClass.CH_ILC_INP) 
        if ilcResult != None:
            if len(ilcResult) > 0 :
                sonuc = ilcResult
                if sonuc[0] == 0x99:
                    return True if sonuc[1] == 0x01 else False
                else:
                    return False
            else:
                return False
        else: 
            return False
    else:
        ilcResult = SendMkk(MessageStructureClass.CH_ILC_INP)

        if ilcResult != None:
            if len(ilcResult) > 0 :
                sonuc = ilcResult#.lastbyte
                if sonuc[4] == 0x99:
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False


def ConnectToMkk():
    instrument = minimalmodbus.Instrument(ComPortMkk, 1)
    read_data=instrument.read_register(1, 1) # register num, decimal
    if read_data != None:
        return True
    else:
        return False


def GetIPAddressFromDb(): #string
    name = EbotParameters.objects.get(paramName = 'MKK_IP')
    value = str(name.paramValue)
    return value

def GetPortFromDb(): #integer
    name = EbotParameters.objects.get(paramName = 'MKK_PORT')
    value = int(name.paramValue)
    return value

def GetComPortFromDb():
    name = EbotParameters.objects.get(paramName = 'MKK_COMPORT')
    value = str(name.paramValue)
    return value


#def ResetCom(): #comu resetlemek bu direkt modbusta yapılabilir bildiğin aç kapa  # burada modbusu yazdıgımızda kendiliğinden acıldıgında bir daha aç dediğimizde zaten acık diyor onu denemeliyiz 
#def ResetComAkdeniz(): #led kartı reset
#def Close(): #socketi kapatmak



