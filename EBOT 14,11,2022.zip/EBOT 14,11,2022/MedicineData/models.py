from django.db import models

# Create your models here.

class MedicineData(models.Model): # Cihaz İÇERİSİNDE bulunan ilaçları ve bilgilerini tutar 
    barcode = models.CharField(max_length = 100)
    name = models.CharField(max_length = 100)
    KB = models.PositiveIntegerField()
    OB = models.PositiveIntegerField()
    BB = models.PositiveIntegerField()
    priority = models.PositiveIntegerField()
    price = models.FloatField()
    minCount = models.PositiveIntegerField()
    orderCount = models.PositiveIntegerField()
    parent = models.PositiveIntegerField()
    child = models.CharField(max_length = 100)
    imgName = models.CharField(max_length = 100)
    isActive = models.BooleanField()
