from django.contrib import admin
from .models import EbotShelf
# Register your models here.
admin.site.register(EbotShelf)