from django.apps import AppConfig


class EbotshelfConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'EbotShelf'
