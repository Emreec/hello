from django.db import models

# Create your models here.

class EbotShelf(models.Model): #İlaçların pozisyon bilgilerini tutar
    position = models.IntegerField() #negatif tutuyor oyuzden normal
    cabinetNo = models.PositiveIntegerField()
    shelfNo = models.PositiveIntegerField()
    heightGroup = models.CharField(max_length = 100)
    widthGroup = models.CharField(max_length = 100)
    xPositionAbs = models.FloatField()
    yPositionAbs = models.FloatField()
    xDeltaPosition = models.FloatField()
    yDeltaPosition = models.FloatField()
    ledStripNo = models.PositiveIntegerField()
    ledNo = models.PositiveIntegerField()
    dedicatedMedicineID = models.PositiveIntegerField()
    dedicatedMedicineCount = models.PositiveIntegerField()
    isActive = models.BooleanField()

    def __str__(self):
        a=str(self.position)
        return a