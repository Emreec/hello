a = 5
b=8
def dön():  
    if a ==5 :
        return True if b == 8 else False



döndür = dön()
