from django.contrib import admin
from .models import DataEbotUser, DataLoginType
from home.forms import CustomUserCreationForm
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User 
# Register your models here.


class CustomUserAdmin(UserAdmin):
    model=DataEbotUser
    add_form=CustomUserCreationForm


admin.site.register(DataEbotUser, CustomUserAdmin)
admin.site.register(DataLoginType)
admin.site.register(User)