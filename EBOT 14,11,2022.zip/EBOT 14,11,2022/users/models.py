
from asyncio.windows_events import NULL
from django.db import models
from django.contrib.auth.models import AbstractUser



# Create your models here.



class DataEbotUser(AbstractUser): #Userı genişlet
    phone=models.CharField(max_length=20)
    LastClientLogin = models.DateTimeField(null=True , blank = True)
    LastServerLogin = models.DateTimeField(null=True , blank=True)
    AllowServerLogin = models.BooleanField(default=False)
    LoginType = models.IntegerField(null=True , blank=True)
    isActive = models.BooleanField(default = False )

   



class DataLoginType(models.Model):
    user = models.ForeignKey(DataEbotUser, null=True , on_delete=models.CASCADE , related_name='LoginType_user')
    name = models.CharField(max_length=200)
    detail = models.CharField(max_length=200)
    isActive = models.ForeignKey(DataEbotUser , on_delete=models.CASCADE , related_name='LoginType_isActive')
    
    def __str__(self):
        return self.name



    