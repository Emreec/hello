from django.db import models

# Create your models here.
class uMedicineModel(models.Model): #İlaçların pozisyon bilgilerini tutar

    uPosition = models.IntegerField() #negatif tutuyor oyuzden norma
    UxPositionAbs = models.FloatField()
    UyPositionAbs = models.FloatField()
    isActive = models.BooleanField()
    
    def __str__(self):
        a=str(self.uPosition)
        return a