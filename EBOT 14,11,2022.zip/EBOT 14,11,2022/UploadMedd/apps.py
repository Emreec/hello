from django.apps import AppConfig


class UploadmeddConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'UploadMedd'
