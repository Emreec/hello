from django.db import models

# Create your models here.
class MedicineModel(models.Model): #İlaçların pozisyon bilgilerini tutar
    MedName = models.CharField(max_length=250)
    Position = models.IntegerField() #negatif tutuyor oyuzden norma
    xPositionAbs = models.FloatField()
    yPositionAbs = models.FloatField()
    isActive = models.BooleanField()
    quantity = models.IntegerField(default=2)
    def __str__(self):
        a=str(self.MedName)
        return a