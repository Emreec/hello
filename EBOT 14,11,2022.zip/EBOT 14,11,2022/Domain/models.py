
from django.db import models
from EbotShelf.models import EbotShelf
from MedicineData.models import MedicineData
from users.models import DataEbotUser
# Create your models here.


class EbotLoad(models.Model):
    medicineID = models.OneToOneField(MedicineData, on_delete=models.CASCADE , related_name='Load_medicineID') #BURADAKİ MEDİCİNE ID FARKLI OLABİLİR 
    userID = models.ForeignKey(DataEbotUser , on_delete=models.CASCADE , related_name='Load_userID' )
    shelfID = models.OneToOneField(EbotShelf , on_delete=models.CASCADE , related_name='Load_shelfID')
    infoSerial = models.CharField(max_length = 100)
    infoParty = models.CharField(max_length = 100)
    infoExpDate = models.DateTimeField()
    #infoQR = models.ForeignKey(LoadedMedicine , on_delete=models.CASCADE , related_name='userID') #birdaha bakılacak bilginin nereden alındıgına
    #loadTime = models.ForeignKey(LoadedMedicine , on_delete=models.CASCADE , related_name='loadTime')
    #hasQR = models.ForeignKey(LoadedMedicine , on_delete=models.CASCADE , related_name='userID')
    infoQR = models.CharField(max_length = 100)
    loadTime = models.DateTimeField()
    hasQR = models.BooleanField()
    isActive = models.BooleanField()
    

class LoadedMedicine(models.Model): #YÜKLENMİŞ İLAÇLARI TUTAR 
    medicineID = models.ForeignKey(MedicineData , on_delete=models.CASCADE, related_name='Loaded_medicineID')
    userID = models.OneToOneField(DataEbotUser , on_delete=models.CASCADE , related_name='Loaded_userID' ) #DATAEBOT USER C#TAKİ İSMİNDEN FARKLI DEĞİŞTİRİLEBİLİR
    shelfID = models.ForeignKey(EbotShelf , on_delete=models.CASCADE , related_name='Loaded_shelfID')
    infoSerial = models.CharField(max_length = 100)
    infoParty = models.CharField(max_length = 100)
    infoExpDate = models.DateTimeField()
    #infoQR = models.CharField(max_length = 100)
    #loadTime = models.DateTimeField()
    #hasQR = models.BooleanField()
    infoQR = models.OneToOneField(EbotLoad , on_delete=models.CASCADE , related_name='Loaded_infoQR') #birdaha bakılacak bilginin nereden alındıgına
    loadTime = models.OneToOneField(EbotLoad , on_delete=models.CASCADE , related_name='Loaded_loadTime' )
    hasQR = models.OneToOneField(EbotLoad , on_delete=models.CASCADE , related_name='Loaded_hasQR' )
    isReserved = models.BooleanField()
    isActive = models.BooleanField()

#C# ta burada CompareLoadedMedicine diye bir şey var ne oldugunu bilmiyoruz 

#---------------------------------#


class EbotParameters(models.Model): #PARAMETRELER 
    paramName = models.CharField(max_length = 100)
    paramType = models.CharField(max_length = 100)
    paramValue = models.CharField(max_length = 100)
    description = models.CharField(max_length = 100)
    defaultValue = models.CharField(max_length = 100)
    isActive = models.BooleanField()

    def __str__(self):
        return self.paramName

#---------------------------------#

class EbotIntStat(models.Model): #Yüklenen ilaçların bilgilerini tutuyor
    medicineID = models.ForeignKey(MedicineData , on_delete=models.CASCADE , related_name='InStat_medicineID')
    userID = models.ForeignKey(DataEbotUser , on_delete=models.CASCADE , related_name='InStat_userID')
    shelfID = models.ForeignKey(EbotShelf , on_delete=models.CASCADE , related_name='InStat_shelfID' )
    loadTime = models.DateTimeField()
    inTime = models.DateTimeField()
    isActive = models.BooleanField()


"""
class DataGridEbotInStat(models.Model):
    queNumber = models.PositiveIntegerField()
    medicineID = models.ForeignKey(EbotIntStat ,on_delete=models.CASCADE , related_name='medicineID')
    medicineName = models.CharField(max_length = 100)
    shelfID = models.ForeignKey(EbotIntStat, on_delete=models.CASCADE , related_name='shelfID')
    shelfNo = models.PositiveIntegerField()
    userName = models.PositiveIntegerField() #USERS database'ine bağlanabilir
    loadTime = models.ForeignKey(EbotIntStat , on_delete=models.CASCADE , related_name='loadTime')
    inTime = models.ForeignKey(EbotIntStat , on_delete=models.CASCADE , related_name= 'inTime')
"""

#---------------------------------#

class EbotOutStat(models.Model):#Giden ilaçların listesini tutar 
    medicineID = models.ForeignKey(MedicineData , on_delete=models.CASCADE, related_name='OutStat_medicineID' )
    userID = models.ForeignKey(DataEbotUser , on_delete=models.CASCADE , related_name='OutStat_userID')
    shelfID = models.ForeignKey(EbotShelf , on_delete=models.CASCADE , related_name='OutStat_shelfID')
    requestTime = models.DateTimeField()
    outTime = models.DateTimeField()
    isActive = models.BooleanField()



#---------------------------------#
"""class EbotLoad(models.Model):
    medicineID = models.ForeignKey(MedicineData, on_delete=models.CASCADE , related_name='medicineID') #BURADAKİ MEDİCİNE ID FARKLI OLABİLİR 
    userID = models.ForeignKey(MedicineData , on_delete=models.CASCADE , related_name='userID')
    shelfID = models.ForeignKey(MedicineData , on_delete=models.CASCADE , related_name='shelfID')
    infoSerial = models.CharField(max_length = 100)
    infoParty = models.CharField(max_length = 100)
    infoExpDate = models.DateTimeField()
    #infoQR = models.ForeignKey(LoadedMedicine , on_delete=models.CASCADE , related_name='userID') #birdaha bakılacak bilginin nereden alındıgına
    #loadTime = models.ForeignKey(LoadedMedicine , on_delete=models.CASCADE , related_name='loadTime')
    #hasQR = models.ForeignKey(LoadedMedicine , on_delete=models.CASCADE , related_name='userID')
    infoQR = models.CharField(max_length = 100)
    loadTime = models.DateTimeField()
    hasQR = models.BooleanField()
    isActive = models.BooleanField()"""

"""
class DataGridEbotLoad(models.Model):
    queNumber = models.ForeignKey(DataGridEbotInStat , on_delete=models.CASCADE, related_name='queNumber')
    medicineID = models.ForeignKey(EbotIntStat , on_delete=models.CASCADE , related_name='medicineID')
    medicineBarcode = models.CharField(max_length = 100)
    medicineName = models.ForeignKey(DataGridEbotInStat , on_delete=models.CASCADE , related_name='medicineName' )
"""

#---------------------------------#


class EbotQue(models.Model):
    loadedMedicineID = models.ForeignKey(MedicineData , on_delete=models.CASCADE , related_name='Que_loadedMedicineID' )
    userID = models.ForeignKey(EbotIntStat , on_delete=models.CASCADE, related_name='Que_userID' )
    servicePoint = models.CharField(max_length = 100)
    requestTime = models.DateTimeField()
    isApproved = models.BooleanField()
    isInProgress = models.BooleanField()
    isActive = models.BooleanField()
    isFast = models.BooleanField()
