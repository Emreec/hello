from django.contrib import admin
from .models import * 

# Register your models here.


admin.site.register(EbotLoad)
admin.site.register(LoadedMedicine)
admin.site.register(EbotParameters)
admin.site.register(EbotIntStat)
admin.site.register(EbotOutStat)
admin.site.register(EbotQue)

