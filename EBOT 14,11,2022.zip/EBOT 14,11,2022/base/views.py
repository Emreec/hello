from collections import UserString
from turtle import update
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import CustomUserCreationForm, EditUserForm 
from django.contrib.auth.forms import UserChangeForm
# Create your views here.

def LoginUser(request):
    page='login'
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(request,username=username,password=password)

        if user is not None:
            login(request,user)
            return redirect('home')

    return render(request,'home/LoginRegister.html',{'page':page})


def LogoutUser(request):
    logout(request)
    return redirect('login')


def RegisterUser(request):
    page='register'
    form=CustomUserCreationForm()
    
    if request.method=='POST':
        form=CustomUserCreationForm(request.POST)
        if form.is_valid():
            user=form.save(commit=False)
            user.save()

            user=authenticate(request,username=user.username,password=request.POST['password1'])

            logout(user)
            return redirect('login')


    context={'form':form,'page':page}
    return render(request,'home/RegisterPage.html',context)

def DeleteUser(request):
    page='register'
    form=CustomUserCreationForm()
    
    if request.method=='POST':
        form=CustomUserCreationForm(request.POST)
        if form.is_valid():
            user=form.save(commit=False)
            user.delete()

            user=authenticate(request,username=user.username,password=request.POST['password1'])

    context={'form':form,'page':page}
    return render(request,'home/DeleteUser.html',context)

def UserSettings(request):
    users=request.user
    form=EditUserForm(instance=users)
    if request.method=='POST':
        form=EditUserForm(request.POST)
        if form.is_valid():
            user=form.save(commit=False)
            user.save()
    
    context={'form':form}
    return render(request,'home/UsersPage.html',context)
    

@login_required(login_url='login') #Created a login requirement for the below functions 
def home(request):
    return render(request,'home/HomePage.html')

@login_required(login_url='login')
def users(request):
    users=User.objects.all()
    context={'users':users}
    return render(request,'index.html',context)



@login_required(login_url='login')
def parameters(request):
    return render(request,'home/Parameters.html')




@login_required(login_url='login')
def EbotManual(request):
    return render(request,'home/EbotManual.html')




@login_required(login_url='login')
def LedManual(request):
    return render(request,'home/LedManual.html')




@login_required(login_url='login')
def TestRutins(request):
    return render(request,'home/TestRutins.html')


