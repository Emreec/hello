from django.forms import ModelForm 
from django.contrib.auth.models import User 
from django.contrib.auth.forms import UserCreationForm ,UserChangeForm
from django import forms

class CustomUserCreationForm(UserCreationForm):
    first_name = forms.CharField(max_length=50)
    last_name = forms.CharField(max_length=50)
    email = forms.EmailField(required=True)
    phone = forms.CharField(max_length=11)

    class Meta:
        model = User
        fields = ['username','first_name','last_name','email','phone','password1','password2']

    
class EditUserForm(UserChangeForm):
    first_name = forms.CharField(max_length=50)
    last_name = forms.CharField(max_length=50)
    email = forms.EmailField(required=True)
    phone = forms.CharField(max_length=11)
    last_login = forms.DateTimeField()
    date_joined = forms.DateTimeField()

    class Meta:
        model = User
        fields = ['username','first_name','last_name','email','phone','last_login','date_joined']

        def get_object(self):
            return self.request.user
