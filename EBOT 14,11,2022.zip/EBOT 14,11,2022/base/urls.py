from django.urls import path 
from . import views

urlpatterns=[
    path('login/',views.LoginUser,name='login'),
    path('logout/',views.LogoutUser,name='logout'),
    path('register/',views.RegisterUser,name='register'),
    path('delete/',views.DeleteUser,name='delete'),
    
    

    path('',views.home,name='home'),
    path('usersSettings/',views.UserSettings,name='userSettings'),
    path('users/',views.users,name='users'),
    path('parameters/',views.parameters,name='parameters'),
    path('EbotManual/',views.EbotManual,name='EbotManual'),
    path('LedManual/',views.LedManual,name='LedManual'),
    path('TestRutins/',views.TestRutins,name='TestRutins')
]